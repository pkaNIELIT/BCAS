using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using BCASClassLibrary;
using System.IO;

public partial class Payee_Organisation_Master : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if ((Convert.ToString(HttpContext.Current.Session["UserId"]).Trim().Length == 0))
        {
            HttpContext.Current.Response.Redirect("~/Home.aspx");
        }
        else
        {

            if (!Page.IsPostBack)
            {
                enabled_disabled_controls('L');
                BindDropDown();
            }
        }
    }
    protected void BindDropDown()
    {
        drpState.Items.Clear();
        // ListItem li = new ListItem("Select", "0");
        // drpState.Items.Add(li);
        
        DataSet ds = new DataSet();
        
        ds = TYP_PAYEE_ORGANISATION_MASTER.GetStates();
        int i = 0;
        while (i < ds.Tables[0].Rows.Count)
        {
            ListItem li = new ListItem();
            li.Value = ds.Tables[0].Rows[i][0].ToString();
            li.Text = ds.Tables[0].Rows[i][1].ToString();
            i++;
            drpState.Items.Add(li);
        }
        drpState.DataBind();
        //drpState.Items[0].Selected = true;
    }
    protected void btn_insert_Click(object sender, EventArgs e)
    {
        lbl_choice.Text = "I";
        enabled_disabled_controls('I');
        txt_payee_organisation_name.Focus();
    }

    protected void btn_update_Click(object sender, EventArgs e)
    {
        lbl_choice.Text = "U";
        enabled_disabled_controls('U');
        txt_payee_organisation_name.Focus();
    }

    protected void btn_search_Click(object sender, EventArgs e)
    {
        lbl_choice.Text = "F";
        enabled_disabled_controls('F');
        txt_payee_organisation_code.Focus();
    }

    protected void btn_save_Click(object sender, EventArgs e)
    {
        if (lbl_choice.Text == "I" || lbl_choice.Text == "U")
        {
            lbl_errors.Visible = true;
            if (!ValidateData())
                return;
            lbl_errors.Visible = false;
        }

        try
        {
            TYP_PAYEE_ORGANISATION_MASTER newobj = new TYP_PAYEE_ORGANISATION_MASTER();
            if (lbl_choice.Text == "I")
                newobj.PAYEE_ORGANISATION_CODE = 0;
            else
                newobj.PAYEE_ORGANISATION_CODE = Convert.ToInt32(txt_payee_organisation_code.Text);
            newobj.PAYEE_ORGANISATION_NAME = txt_payee_organisation_name.Text.ToUpper();
            newobj.States = drpState.SelectedItem.Text;
            newobj.SCODE = Convert.ToInt32(drpState.SelectedValue);
            newobj.GSTIN = txtGSTIN.Text;
            newobj.ENTER_DATE = DateTime.Now;
            newobj.ENTER_BY = HttpContext.Current.User.Identity.Name;

            switch (lbl_choice.Text)
            {
                case "I":
                    txt_payee_organisation_code.Text = TYP_PAYEE_ORGANISATION_MASTER.InsertPayee_Organisation_Master(newobj).ToString();
                    lbl_error.Text = " Record Successfully Saved ";
                    break;
                case "U":
                    TYP_PAYEE_ORGANISATION_MASTER.UpdatePayee_Organisation_Master(newobj);
                    lbl_error.Text = " Record Successfully Updated ";
                    break;
                case "D":
                    TYP_PAYEE_ORGANISATION_MASTER.DeletePayee_Organisation_Master(Convert.ToInt32(txt_payee_organisation_code.Text));
                    lbl_error.Text = " Record Successfully Deleted ";
                    break;
            }

            GridParameter(txt_payee_organisation_code.Text, "*");
            enabled_disabled_controls('S');
        }
        catch (SqlException ex)
        {
            Int32 ErrorCode = ex.Number;

            switch (ErrorCode)
            {
                case 2627:
                    lbl_error.Text = "Primary key Already Exists, unique constraint violated";
                    break;
                default:
                    lbl_error.Text = ex.Message;
                    break;
            }
            enabled_disabled_controls('N');
        }

        finally
        {
            btn_insert.Focus();
        }
    }

    protected void btn_cancel_Click(object sender, EventArgs e)
    {
        enabled_disabled_controls('C');
        btn_insert.Focus();
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        txt_payee_organisation_code.Text = GridView1.SelectedRow.Cells[1].Text;
        txt_payee_organisation_name.Text = GridView1.SelectedRow.Cells[2].Text;
        if(GridView1.SelectedRow.Cells[4].Text !="&nbsp;")
            drpState.SelectedValue =GridView1.SelectedRow.Cells[4].Text;
        if (GridView1.SelectedRow.Cells[5].Text != "&nbsp;")
        txtGSTIN.Text = GridView1.SelectedRow.Cells[5].Text;
        enabled_disabled_controls('G');
    }

    void enabled_disabled_controls(char choice)
    {
        switch (choice)
        {
            case 'L': //Login
                lbl_error.Text = "";
                btn_insert.Enabled = true;
                btn_search.Enabled = true;
                btn_update.Enabled = false;
                btn_save.Enabled = false;
                btn_cancel.Enabled = false;
                
                enabled_disabled_validation(false);
                frm_panel.Enabled = false;
                break;

            case 'N':  //Exception
                btn_insert.Enabled = false;
                btn_search.Enabled = false;
                btn_update.Enabled = false;
                btn_save.Enabled = true;
                btn_cancel.Enabled = true;
                
                frm_panel.Enabled = true;
                enabled_disabled_validation(true);
                enabled_disabled_controls(true);
                break;
            case 'S':
                // on save
                btn_insert.Enabled = true;
                btn_search.Enabled = true;
                btn_update.Enabled = false;
                btn_save.Enabled = false;
                btn_cancel.Enabled = false;
               

                enabled_disabled_validation(false);
                frm_panel.Enabled = false;
                enabled_disabled_controls(false);
                clear_contents();
                break;
            case 'C':
                //on  cancel
                btn_insert.Enabled = true;
                btn_search.Enabled = true;
                btn_update.Enabled = false;
                btn_save.Enabled = false;
                btn_cancel.Enabled = false;
                

                enabled_disabled_validation(false);
                frm_panel.Enabled = false;
                enabled_disabled_controls(false);
                clear_contents();
                break;
            case 'I':
                lbl_error.Text = "";
                btn_insert.Enabled = false;
                btn_update.Enabled = false;
                btn_search.Enabled = false;
               
                btn_save.Enabled = true;
                btn_cancel.Enabled = true;
                frm_panel.Enabled = true;
                enabled_disabled_validation(true);
                enabled_disabled_controls(true);
                txt_payee_organisation_code.Enabled = false;
                break;
            case 'F':
                btn_insert.Enabled = false;
                btn_search.Enabled = false;
                btn_update.Enabled = false;
                
                btn_save.Enabled = false;
                btn_cancel.Enabled = true;
                frm_panel.Enabled = true;
                enabled_disabled_validation(false);
                enabled_disabled_controls(true);
                break;
            case 'U':
                btn_insert.Enabled = false;
                btn_update.Enabled = false;
                btn_search.Enabled = false;
                
                btn_save.Enabled = true;
                btn_cancel.Enabled = true;
                frm_panel.Enabled = true;
                enabled_disabled_validation(true);
                enabled_disabled_controls(true);
                txt_payee_organisation_code.Enabled = false;
                break;
            case 'G':
                lbl_error.Text = "";
                btn_insert.Enabled = false;
                btn_search.Enabled = false;
                btn_update.Enabled = true;
                
                btn_save.Enabled = false;
                btn_cancel.Enabled = true;

                enabled_disabled_validation(false);
                frm_panel.Enabled = false;
                break;
        };
    }

    void clear_contents()
    {
        lbl_choice.Text = "";
        lbl_error.Text = "";
        txt_payee_organisation_code.Text = "";
        txt_payee_organisation_name.Text = "";
        txtGSTIN.Text = "";
        BindDropDown();
        
    }

    void enabled_disabled_controls(bool flag)
    {
        txt_payee_organisation_code.Enabled = flag;
        txt_payee_organisation_name.Enabled = flag;
    }

    void enabled_disabled_validation(bool flag)
    {
        mev_payee_organisation_name.Enabled = flag;
    }
           
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
        {
            foreach (DataControlFieldCell cell in e.Row.Cells)
            {
                cell.Width = cell.Text.Trim().Length;
            }
        }
        else if (e.Row.RowType == DataControlRowType.DataRow)
            {
            e.Row.Cells[7].Text = Convert.ToDateTime(e.Row.Cells[7].Text).Date.ToString("dd-MMM-yyyy").ToUpper().Trim();
            }
    }
    protected void btn_display_Click(object sender, EventArgs e)
    {
        lbl_error.Text = "";
        string pPayee_Organisation_Code, pPayee_Organisation_Name;

        if (txt_payee_organisation_code.Text == "")
            pPayee_Organisation_Code = "-1";
        else
            pPayee_Organisation_Code = txt_payee_organisation_code.Text.ToUpper();

        if (txt_payee_organisation_name.Text == "")
            pPayee_Organisation_Name = "*";
        else
            pPayee_Organisation_Name = txt_payee_organisation_name.Text.ToUpper();

             //-----Setting Grid Parameters-----------------------------------------
        GridParameter(pPayee_Organisation_Code, pPayee_Organisation_Name);
    }

    private void GridParameter(string pPayee_Organisation_Code, string pPayee_Organisation_Name)
    {
        Parameter objPayee_Organisation_CodeParameter = new Parameter("pPayee_Organisation_Code", TypeCode.String, pPayee_Organisation_Code);
        Parameter objPayee_Organisation_NameParameter = new Parameter("pPayee_Organisation_Name", TypeCode.String, pPayee_Organisation_Name);

        //set up object data source parameters
        ObjectDataSource1.SelectParameters["pPayee_Organisation_Code"] = objPayee_Organisation_CodeParameter;
        ObjectDataSource1.SelectParameters["pPayee_Organisation_Name"] = objPayee_Organisation_NameParameter;

        //Rebinding Data Grid
        GridView1.DataBind();
    }   


    protected bool ValidateData()
    {
        bool valid = true;
        bullet_errors.Items.Clear();
        //--------------------------------------------------------------------
        mev_payee_organisation_name.Validate();
        if (!mev_payee_organisation_name.IsValid)
        {
            bullet_errors.Items.Add("Payee Organisation Name must be Entered");
            valid = false;
        }

        return valid;
    }
}
